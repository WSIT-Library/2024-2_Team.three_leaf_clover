package com.example.happyDream.Interface;

import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "ChargerState", description = "충전기 상태 API")
public interface ChargerStateSwagger {
}
